/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Interface;

/**
 *
 * @author User
 */
public interface TableDB {
    public abstract void tampilkanPesanan();
    public abstract void kosongkanPesanan();
}
