/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Interface;

/**
 *
 * @author User
 */
public interface Kota {
    public String[][] bandara = {
        {"Jakarta (JKTA)", "Surabaya (SUB)", "Bali (DPS)", "Padang (PDG)","Semarang (SRG)"},
        {"Soekarno Hatta International Airport", "Juanda Airport", "Ngurah Rai International Airport", "Minangkabau Intl","Achmad Yani Airport"},
        {"Airport Terminal 3", "Terminal 1A", "Terminal Domestic", "Terminal Domestic", "Terminal Domestic"}
    };
    
    public void randomKodePesawat();
}
